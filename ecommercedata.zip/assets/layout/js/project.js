$(function(){
	var path="http://localhost/ecommercedata/Home/";
	$("#btn_login").click(function(){
		$.ajax({
			type:"post",
			data:$("#login_action").serialize(),
			url: path+"login_action",
			success:function(ans_from_data){
				// alert(ans_from_data);
				
				if(ans_from_data == 1){
				$("#err_regis").html(ans_from_data);
					setTimeout(function(){
						// $("#err_regis").html("Registration Done Successfully");
						window.location.href=path+"index";
					},2000);	
				}
			}
		})
	})
	$("#btn_loginaction").click(function(){
		// alert(1111);
		$.ajax({

			type:'post',
			data:$("#log_action").serialize(),
			url:path+"log_action",
			success:function(ans_from_data){
				// alert(ans_from_data);
				if(ans_from_data == 1)
				{
					window.location.href=path+"index";
				}
				else{
					$("#logs_err").html(ans_from_data);
				}
			}
		})
	})
})