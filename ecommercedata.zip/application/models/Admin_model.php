<?php 

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Admin_model extends CI_Model{


		function regis_data($data){
			$this->db->insert("user_register",$data);
		}
		function check_record($email,$pass){
				// echo "select log_id,log_fname,log_lname,log_gender,log_email,log_pass,log_mobile,log_state,log_city,log_dob,log_time from user_register where log_email='".$email."'AND log_pass='".$pass."'";
			$this->db->select("log_id,log_fname,log_lname,log_gender,log_email,log_pass,log_mobile,log_state,log_city,log_dob,log_time");
			$ans=$this->db->get_where('user_register',array('log_email'=>$email,'log_pass'=>$pass));
			// print_r($ans->num_rows > 0)
			if($ans->num_rows > 0){
				// print_r($ans->result());
				return $ans->result();
			}
			else
			{
				return 0;
			}
		}


	}



 ?>