<?php 

	class Myclass{
		var $ci='';
		public function __construct()
		{
			$this->ci=& get_instance();
		}

		public function mailfunction($to,$from,$subject,$message)
		{
			

			$config['protocol'] = "smtp";
			$config['smtp_host'] = "ssl://smtp.gmail.com";
			$config['smtp_port'] = "465";
			$config['smtp_user'] = "dixitshah075@gmail.com"; 
			$config['smtp_pass'] = "milesh1994";
			$config['charset'] = "utf-8";
			$config['mailtype'] = "html";
			$config['newline'] = "\r\n";	

			$this->ci->email->initialize($config);

			$this->ci->email->from($from, 'Ecommerce Website');
			$list = array($to);
			$this->ci->email->to($list);
			
			$this->ci->email->subject($subject);
			$this->ci->email->message($message);
			$ans=$this->ci->email->send();

	}
	public function get_client_ip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
	}


	}
	

 ?>