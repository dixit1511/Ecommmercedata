<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Login to your account</h2>
						<form type="post" id="log_action">
							<div id="logs_err"></div>
							<input type="text" placeholder="Email Address" name='log_email'/>
							<input type="password" placeholder="Password" name='log_pass' />
							
							<button type="button" id="btn_loginaction" class="btn btn-default">Login</button>
						</form>
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h2 class="or">OR</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>New User Signup!</h2>
						<form type="post" id="login_action">
							<div id="err_regis"></div>
							<input type="text" placeholder="First Name" type="text" name="log_fname" />
							<input type="text" placeholder="Last Name" type="text" name="log_lname" />

							<!-- <div class="col-sm-12">
								<div class="col-sm-6">
										Male <input type="radio" name="log_gender">
								</div>
								<div class="col-sm-6">
									Female <input type="radio" name="log_gender" >
								</div>
							</div> -->
      						
							<input type="email" placeholder="Email ID" type="text" name="log_email"/>
							<input type="password" placeholder="Password" type="text" name="log_pass"/>
							<input type="password" placeholder="Confirm Password" type="text" name="log_cpass"/>
							
							<input type="text" placeholder="Mobile Number" type="text" name="log_mobile" />

							<input type="text" class="form-control" placeholder="Date Of Birth"  data-toggle="datepicker">


							<!-- <select class="form-control">
								<option>Select State</option>
							</select>
							<select class="form-control">
								<option>Select City</option>
							</select>
							 -->

							<button type="button" id="btn_login" class="btn btn-default">Signup</button>
						</form>

					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->