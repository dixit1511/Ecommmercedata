<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class Home extends CI_Controller{
 	
 	function __construct(){
 		 parent::__construct();
 		$this->load->model('Admin_model');
 		$this->load->library('email');

 	} 

 	public function index(){
 		$this->load->view("header");
 		$this->load->view("index");
 		$this->load->view("footer");
 	}
 	public function login(){
 		$this->load->view("header");
 		$this->load->view("login");
 		$this->load->view("footer");
 			
 	}
 	public function login_action(){

 		$ans=$this->input->post();
 		// print_r($ans);
 		$this->form_validation->set_rules("log_fname","First Name","trim|required|min_length[3]|max_length[40]");
 		$this->form_validation->set_rules("log_lname","Last Name","trim|required|min_length[3]|max_length[40]");
 		$this->form_validation->set_rules("log_email","Email ID",'trim|required|is_unique[user_register.log_email]');
 		$this->form_validation->set_rules("log_pass","Password","trim|required|min_length[8]|matches[log_cpass]");
 		$this->form_validation->set_rules("log_cpass","Confirm Password","trim|required|min_length[8]");
 		$this->form_validation->set_rules("log_mobile","Mobile Number","trim|required|min_length[10]|max_length[10]");
 		if ($this->form_validation->run() == FALSE)
		{
			// echo "<div style='font-size:12'>".validation_errors()."</div>";
			echo "<div style='font-size:12;color: rgb(228, 33, 33);font-weight: 700;'>".validation_errors()."</div>";
		}
		else
		{
			// print_r(do_hash($ans['log_cpass']));
			unset($ans['log_cpass']);
			$pass=$ans['log_pass'];
			$ans['log_pass']=do_hash($ans['log_pass']);

			$this->Admin_model->regis_data($ans);
			$to=$ans['log_email'];
			$from='dixitshah075@gmail.com';
			$subject="All Under Rs 299";
			$message="Hi, ".ucfirst($ans['log_fname'])."<br>Your Registration Done Successfully. <br> Your Email Id Is :- ".$ans['log_email']." <br> password is:- ".$pass." <br> please login with below url<br><a href='".base_url()."Home/login'> Login With Us </a>";
			/*sms integration*/

			//Your authentication key
			 $authKey = "177578AcBhGF5Vcxk5b5ed53b";

			//Multiple mobiles numbers separated by comma

			$mobileNumber = '91'.$ans['log_mobile'];

			//Sender ID,While using route4 sender id should be 6 characters long.

			$senderId = "WIKORL";
			//Your message to send, Add URL encoding here.

			$messages = urlencode("Dear ".ucwords($ans['log_fname'])."., Thank you for Registration. LOGIN details are Mobile :".$ans['log_email']."Team Ecommerce  – Makers of Dixit Shah");

			//Define route

			$route = "6";
			 //Prepare you post parameters

			$postData = array(

			'authkey' => $authKey,

			'mobiles' => $mobileNumber,

			'message' => $messages,

			'sender' => $senderId,

			'route' => $route
			);
			//API URL

			$url="https://control.msg91.com/api/sendhttp.php";
			// init the resource

			$ch = curl_init();

			curl_setopt_array($ch, array( 
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $postData
			//,CURLOPT_FOLLOWLOCATION => true
			));

			//Ignore SSL certificate verification
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			//get response
			$output = curl_exec($ch);
			//Print error if any
			if(curl_errno($ch))
			{

			 echo 'error:' . curl_error($ch);

			}
			curl_close($ch);
			// echo $output;


			$this->load->library('Myclass');

			$this->myclass->mailfunction($to,$from,$subject,$message);
			
			$this->session->set_userdata('log_fname',$ans['log_fname']);
			$this->session->set_userdata('log_lname',$ans['log_lname']);
			$this->session->set_userdata('log_email',$ans['log_email']);
			$this->session->set_userdata('log_mobile',$ans['log_mobile']);

			echo 1;
		}
 	}

 	public function logout(){
 			$this->session->unset_userdata('log_fname',$ans['log_fname']);
			$this->session->unset_userdata('log_lname',$ans['log_lname']);
			$this->session->unset_userdata('log_email',$ans['log_email']);
			$this->session->unset_userdata('log_mobile',$ans['log_mobile']);

			redirect('Home/login');
 	}

 	public function log_action(){
 		$ans=$this->input->post();
 		// print_r($ans);
 		$this->form_validation->set_rules("log_email","Email ID","trim|required|valid_email");
 		$this->form_validation->set_rules("log_pass","Password","trim|required|min_length[8]");
 		if ($this->form_validation->run() == FALSE)
		{
			// echo "<div style='font-size:12'>".validation_errors()."</div>";
			echo "<div style='font-size:12;color: rgb(228, 33, 33);font-weight: 700;'>".validation_errors()."</div>";
		}
		else{
			// echo "111";
			$ansdata=$this->Admin_model->check_record($ans['log_email'],do_hash($ans['log_pass']));
			// print_r($ans);
			if($ansdata == 0){
				echo "<div style='font-size:12;color: rgb(228, 33, 33);font-weight: 700;'> Please check your login Details</div>";
			}
			else{
				// print_r($ansdata[0]->log_fname);
			$this->session->set_userdata('log_fname',$ansdata[0]->log_fname);
			$this->session->set_userdata('log_lname',$ansdata[0]->log_lname);
			$this->session->set_userdata('log_email',$ans['log_email']);
			$this->session->set_userdata('log_mobile',$ansdata[0]->log_mobile);
			// $_SERVER['HTTP_USER_AGENT']
			// $browserdeails=get_browser();			
			// echo "<pre>";
			// print_r($browserdeails);
			// echo "<pre>";
			// $ip=$_SERVER['REMOTE_HOST'];
			// echo $ip;
			// $ip=$this->myclass->get_client_ip();
			echo 1;
			// print_r($ip);		
			}

		}
 	}

 }



 ?>